
from pathlib import Path

# Project root directory
BASE_DIR = Path(__file__).resolve().parent.parent

# Main project directories
DATASET_DIR = BASE_DIR / "datasets"
MODEL_DIR = BASE_DIR / "models"
REPORT_DIR = BASE_DIR / "reports"

# Smart grid configuration
PROJECT_NAME = "AI-Powered Intelligent Load Balancing System"

ZONES = [
    "Hospital",
    "Emergency Centre",
    "Residential",
    "Commercial",
    "Industrial"
]

# Simulation configuration
SIMULATION_INTERVAL = 60  # minutes
TOTAL_ZONES = len(ZONES)

# Energy measurement
ENERGY_UNIT = "kWh"
