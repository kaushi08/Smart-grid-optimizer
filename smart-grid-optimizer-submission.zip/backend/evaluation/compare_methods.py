
import pandas as pd
from pathlib import Path

from backend.optimization.load_optimizer import optimize_energy_allocation

# Project paths
BASE_DIR = Path(__file__).resolve().parents[2]
PREDICTION_FILE = BASE_DIR / "reports" / "next_hour_predictions.csv"
SUPPLY_FILE = BASE_DIR / "datasets" / "system_supply_dataset.csv"
REPORT_DIR = BASE_DIR / "reports"

ZONE_PRIORITY = {
    "Hospital": 1,
    "Emergency Centre": 1,
    "Residential": 2,
    "Commercial": 3,
    "Industrial": 3
}


def proportional_allocation(demand, usable_supply):
    total_demand = sum(demand.values())

    if total_demand <= 0:
        return {zone: 0.0 for zone in demand}

    ratio = min(1.0, usable_supply / total_demand)

    return {
        zone: demand[zone] * ratio
        for zone in demand
    }


def priority_based_allocation(demand, usable_supply):
    allocation = {zone: 0.0 for zone in demand}
    remaining_supply = usable_supply

    # Lower priority number means higher priority
    for zone in sorted(demand, key=lambda z: ZONE_PRIORITY[z]):

        allocated = min(demand[zone], remaining_supply)

        allocation[zone] = allocated
        remaining_supply -= allocated

    return allocation


def calculate_metrics(demand, allocation):
    total_demand = sum(demand.values())
    total_allocated = sum(allocation.values())
    unmet_demand = sum(
        max(0.0, demand[zone] - allocation[zone])
        for zone in demand
    )

    satisfaction = (
        total_allocated / total_demand * 100
        if total_demand > 0 else 100.0
    )

    return {
        "total_demand_kwh": round(total_demand, 2),
        "total_allocated_kwh": round(total_allocated, 2),
        "unmet_demand_kwh": round(unmet_demand, 2),
        "demand_satisfaction_percentage": round(satisfaction, 2)
    }


def run_comparison():

    print("\n========== ALLOCATION METHOD COMPARISON ==========")

    # 1. Load predictions
    predictions = pd.read_csv(PREDICTION_FILE)

    demand = dict(zip(
        predictions["zone"],
        predictions["predicted_demand_kwh"]
    ))

    # 2. Load latest supply
    supply_data = pd.read_csv(SUPPLY_FILE)

    latest_supply = supply_data.sort_values("timestamp").iloc[-1]

    available_supply = float(
        latest_supply["total_available_supply_kwh"]
    )

    # 3. Apply reserve
    reserved_supply = 50.0
    usable_supply = max(0.0, min(available_supply, 1000.0) - reserved_supply)

    # 4. Proportional allocation
    proportional = proportional_allocation(demand, usable_supply)

    # 5. Priority-based allocation
    priority = priority_based_allocation(demand, usable_supply)

    # 6. Proposed AI + optimization method
    proposed_result = optimize_energy_allocation(
        demand,
        available_supply
    )

    proposed = {
        zone: values["allocated_kwh"]
        for zone, values in proposed_result["zones"].items()
    }

    methods = {
        "Proportional": proportional,
        "Priority-Based": priority,
        "AI + Optimization": proposed
    }

    # 7. Calculate performance metrics
    summary = []
    zone_results = []

    for method_name, allocation in methods.items():

        metrics = calculate_metrics(demand, allocation)

        summary.append({
            "method": method_name,
            **metrics
        })

        for zone in demand:

            zone_results.append({
                "method": method_name,
                "zone": zone,
                "predicted_demand_kwh": round(demand[zone], 2),
                "allocated_kwh": round(allocation[zone], 2),
                "unmet_demand_kwh": round(
                    max(0.0, demand[zone] - allocation[zone]), 2
                ),
                "satisfaction_percentage": round(
                    allocation[zone] / demand[zone] * 100
                    if demand[zone] > 0 else 100.0,
                    2
                )
            })

    # 8. Save reports
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    summary_df = pd.DataFrame(summary)
    zone_df = pd.DataFrame(zone_results)

    summary_file = REPORT_DIR / "method_comparison_summary.csv"
    zone_file = REPORT_DIR / "method_comparison_zone_details.csv"

    summary_df.to_csv(summary_file, index=False)
    zone_df.to_csv(zone_file, index=False)

    # 9. Display results
    print("\nAvailable supply:", round(available_supply, 2), "kWh")
    print("Reserved supply:", reserved_supply, "kWh")
    print("Usable supply:", round(usable_supply, 2), "kWh")

    print("\n========== OVERALL COMPARISON ==========")
    print(summary_df.to_string(index=False))

    print("\n========== ZONE-WISE COMPARISON ==========")
    print(zone_df.to_string(index=False))

    print("\nSummary saved:", summary_file)
    print("Zone details saved:", zone_file)

    print("\nPERFORMANCE COMPARISON COMPLETED")


if __name__ == "__main__":
    run_comparison()
