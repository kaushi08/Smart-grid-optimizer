
import pandas as pd
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
REPORT_DIR = BASE_DIR / "reports"

INPUT_FILE = REPORT_DIR / "multi_day_evaluation_details.csv"

CRITICAL_ZONES = ["Hospital", "Emergency Centre"]


def calculate_advanced_metrics(data):

    results = []

    for method, group in data.groupby("method"):

        total_demand = group["demand_kwh"].sum()
        total_allocated = group["allocated_kwh"].sum()

        # Overall demand satisfaction
        overall_satisfaction = (
            total_allocated / total_demand * 100
            if total_demand > 0 else 100
        )

        # Critical-zone satisfaction
        critical = group[group["zone"].isin(CRITICAL_ZONES)]

        critical_demand = critical["demand_kwh"].sum()
        critical_allocated = critical["allocated_kwh"].sum()

        critical_satisfaction = (
            critical_allocated / critical_demand * 100
            if critical_demand > 0 else 100
        )

        # Average zone satisfaction
        zone_satisfaction = (
            group.groupby("zone")["satisfaction_percentage"].mean()
        )

        # Jain's fairness index based on zone satisfaction ratios
        satisfaction_ratios = zone_satisfaction.values / 100

        fairness = (
            satisfaction_ratios.sum() ** 2 /
            (len(satisfaction_ratios) *
             (satisfaction_ratios ** 2).sum())
            if (satisfaction_ratios ** 2).sum() > 0 else 1
        )

        # Number of hours with zero unmet demand in critical zones
        critical_hourly = critical.groupby("timestamp").agg(
            demand=("demand_kwh", "sum"),
            unmet=("unmet_demand_kwh", "sum")
        )

        critical_fully_satisfied_hours = (
            (critical_hourly["unmet"] < 0.01).sum()
        )

        results.append({
            "method": method,
            "overall_satisfaction_percentage": round(
                overall_satisfaction, 2
            ),
            "critical_zone_satisfaction_percentage": round(
                critical_satisfaction, 2
            ),
            "jains_fairness_index": round(fairness, 4),
            "critical_fully_satisfied_hours": int(
                critical_fully_satisfied_hours
            ),
            "total_unmet_demand_kwh": round(
                group["unmet_demand_kwh"].sum(), 2
            )
        })

    return pd.DataFrame(results)


def run_advanced_metrics():

    print("\n========== ADVANCED PERFORMANCE METRICS ==========")

    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            "Run multi_day_evaluation.py first."
        )

    data = pd.read_csv(INPUT_FILE)

    required_columns = {
        "timestamp",
        "method",
        "zone",
        "demand_kwh",
        "allocated_kwh",
        "unmet_demand_kwh",
        "satisfaction_percentage"
    }

    missing = required_columns - set(data.columns)

    if missing:
        raise ValueError(f"Missing columns: {missing}")

    if data.empty:
        raise ValueError("Evaluation file contains no records.")

    metrics = calculate_advanced_metrics(data)

    output_file = REPORT_DIR / "advanced_performance_metrics.csv"
    metrics.to_csv(output_file, index=False)

    print("\nAdvanced metrics:")
    print(metrics.to_string(index=False))

    print("\nSaved:", output_file)
    print("\nADVANCED METRICS COMPLETED SUCCESSFULLY")


if __name__ == "__main__":
    run_advanced_metrics()
