
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
REPORT_DIR = BASE_DIR / "reports"

SUMMARY_FILE = REPORT_DIR / "method_comparison_summary.csv"
ZONE_FILE = REPORT_DIR / "method_comparison_zone_details.csv"

print("\n========== PERFORMANCE VISUALIZATION ==========")

if not SUMMARY_FILE.exists():
    raise FileNotFoundError(
        "Run compare_methods.py first. Summary CSV is missing."
    )

if not ZONE_FILE.exists():
    raise FileNotFoundError(
        "Run compare_methods.py first. Zone details CSV is missing."
    )

summary = pd.read_csv(SUMMARY_FILE)
zone_data = pd.read_csv(ZONE_FILE)

# Chart 1: Overall demand satisfaction
plt.figure(figsize=(9, 5))
plt.bar(
    summary["method"],
    summary["demand_satisfaction_percentage"]
)
plt.title("Demand Satisfaction by Allocation Method")
plt.xlabel("Allocation Method")
plt.ylabel("Demand Satisfaction (%)")
plt.ylim(0, 110)
plt.grid(axis="y", linestyle="--", alpha=0.5)
plt.tight_layout()

plt.savefig(
    REPORT_DIR / "overall_satisfaction_comparison.png",
    dpi=300
)
plt.close()

# Chart 2: Zone-wise energy allocation
allocation_pivot = zone_data.pivot(
    index="zone",
    columns="method",
    values="allocated_kwh"
)

allocation_pivot.plot(
    kind="bar",
    figsize=(11, 6)
)
plt.title("Zone-wise Energy Allocation Comparison")
plt.xlabel("Grid Zone")
plt.ylabel("Allocated Energy (kWh)")
plt.xticks(rotation=20)
plt.grid(axis="y", linestyle="--", alpha=0.5)
plt.tight_layout()

plt.savefig(
    REPORT_DIR / "zone_allocation_comparison.png",
    dpi=300
)
plt.close()

# Chart 3: Zone-wise unmet demand
unmet_pivot = zone_data.pivot(
    index="zone",
    columns="method",
    values="unmet_demand_kwh"
)

unmet_pivot.plot(
    kind="bar",
    figsize=(11, 6)
)
plt.title("Zone-wise Unmet Demand Comparison")
plt.xlabel("Grid Zone")
plt.ylabel("Unmet Demand (kWh)")
plt.xticks(rotation=20)
plt.grid(axis="y", linestyle="--", alpha=0.5)
plt.tight_layout()

plt.savefig(
    REPORT_DIR / "zone_unmet_demand_comparison.png",
    dpi=300
)
plt.close()

print("\nThree performance charts generated successfully!")

print("\nSaved charts:")
print("1. overall_satisfaction_comparison.png")
print("2. zone_allocation_comparison.png")
print("3. zone_unmet_demand_comparison.png")

print("\nPERFORMANCE VISUALIZATION COMPLETED")
