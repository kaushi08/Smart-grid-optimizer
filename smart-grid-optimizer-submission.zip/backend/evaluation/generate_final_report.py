
from datetime import datetime

import pandas as pd

from backend.config import REPORT_DIR


# Input report files
METHOD_FILE = REPORT_DIR / "method_comparison_summary.csv"
MULTI_DAY_FILE = REPORT_DIR / "multi_day_evaluation_summary.csv"
ADVANCED_FILE = REPORT_DIR / "advanced_performance_metrics.csv"

# Output report
OUTPUT_FILE = REPORT_DIR / "final_project_performance_report.csv"


def load_report(file_path, required_columns):
    if not file_path.exists():
        raise FileNotFoundError(
            f"Required report file not found: {file_path}"
        )

    df = pd.read_csv(file_path)

    missing = [
        column for column in required_columns
        if column not in df.columns
    ]

    if missing:
        raise ValueError(
            f"Missing columns in {file_path.name}: {missing}"
        )

    if df.empty:
        raise ValueError(f"The file is empty: {file_path.name}")

    return df[required_columns].copy()


def generate_final_report():
    print("\n========== FINAL PROJECT PERFORMANCE REPORT ==========\n")

    # Load method comparison results
    method_df = load_report(
        METHOD_FILE,
        [
            "method",
            "total_demand_kwh",
            "total_allocated_kwh",
            "unmet_demand_kwh",
            "demand_satisfaction_percentage"
        ]
    )

    # Load multi-day evaluation results
    multi_day_df = load_report(
        MULTI_DAY_FILE,
        [
            "method",
            "average_satisfaction_percentage",
            "overall_demand_satisfaction_percentage"
        ]
    )

    # Load advanced performance metrics
    advanced_df = load_report(
        ADVANCED_FILE,
        [
            "method",
            "critical_zone_satisfaction_percentage",
            "jains_fairness_index",
            "critical_fully_satisfied_hours"
        ]
    )

    # Check for duplicate method records
    for name, df in [
        ("Method comparison", method_df),
        ("Multi-day evaluation", multi_day_df),
        ("Advanced metrics", advanced_df)
    ]:
        if df["method"].duplicated().any():
            raise ValueError(
                f"Duplicate method records found in {name}."
            )

    # Combine the three evaluation reports
    final_df = method_df.merge(
        multi_day_df,
        on="method",
        how="outer",
        validate="one_to_one"
    )

    final_df = final_df.merge(
        advanced_df,
        on="method",
        how="outer",
        validate="one_to_one"
    )

    # Sort methods for consistent presentation
    method_order = [
        "AI + Optimization",
        "Priority-Based",
        "Proportional"
    ]

    final_df["_sort_order"] = final_df["method"].apply(
        lambda method: (
            method_order.index(method)
            if method in method_order
            else len(method_order)
        )
    )

    final_df = final_df.sort_values("_sort_order")
    final_df = final_df.drop(columns=["_sort_order"])

    # Round numerical values for readability
    numeric_columns = final_df.select_dtypes(
        include="number"
    ).columns

    final_df[numeric_columns] = final_df[numeric_columns].round(2)

    # Save consolidated report
    final_df.to_csv(OUTPUT_FILE, index=False)

    print("Report generated successfully!")
    print(f"\nSaved at: {OUTPUT_FILE}")

    print("\n========== CONSOLIDATED RESULTS ==========\n")
    print(final_df.to_string(index=False))

    print("\n==========================================")
    print(f"Number of methods evaluated: {len(final_df)}")
    print(f"Report generated at: {datetime.now():%Y-%m-%d %H:%M:%S}")
    print("==========================================\n")


if __name__ == "__main__":
    generate_final_report()
