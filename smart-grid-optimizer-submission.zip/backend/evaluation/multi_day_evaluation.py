
import pandas as pd
from pathlib import Path

from backend.optimization.load_optimizer import optimize_energy_allocation

BASE_DIR = Path(__file__).resolve().parents[2]
DATASET_DIR = BASE_DIR / "datasets"
REPORT_DIR = BASE_DIR / "reports"

ZONE_FILE = DATASET_DIR / "smart_grid_dataset.csv"
SUPPLY_FILE = DATASET_DIR / "system_supply_dataset.csv"

ZONE_PRIORITY = {
    "Hospital": 1,
    "Emergency Centre": 1,
    "Residential": 2,
    "Commercial": 3,
    "Industrial": 3
}

RESERVED_SUPPLY = 50.0
MAXIMUM_SUPPLY = 1000.0


def proportional_allocation(demand, usable_supply):
    total_demand = sum(demand.values())

    if total_demand <= 0:
        return {zone: 0.0 for zone in demand}

    ratio = min(1.0, usable_supply / total_demand)

    return {
        zone: demand[zone] * ratio
        for zone in demand
    }


def priority_allocation(demand, usable_supply):
    allocation = {zone: 0.0 for zone in demand}
    remaining = usable_supply

    for zone in sorted(demand, key=lambda z: (ZONE_PRIORITY[z], z)):
        allocated = min(demand[zone], remaining)
        allocation[zone] = allocated
        remaining -= allocated

    return allocation


def evaluate_allocation(timestamp, method, demand, allocation):
    records = []

    for zone in demand:
        unmet = max(0.0, demand[zone] - allocation[zone])

        satisfaction = (
            allocation[zone] / demand[zone] * 100
            if demand[zone] > 0 else 100.0
        )

        records.append({
            "timestamp": timestamp,
            "method": method,
            "zone": zone,
            "demand_kwh": round(demand[zone], 2),
            "allocated_kwh": round(allocation[zone], 2),
            "unmet_demand_kwh": round(unmet, 2),
            "satisfaction_percentage": round(satisfaction, 2)
        })

    return records


def run_multi_day_evaluation():

    print("\n========== MULTI-DAY PERFORMANCE EVALUATION ==========")

    if not ZONE_FILE.exists() or not SUPPLY_FILE.exists():
        raise FileNotFoundError("Required dataset files are missing.")

    zone_data = pd.read_csv(ZONE_FILE, parse_dates=["timestamp"])
    supply_data = pd.read_csv(SUPPLY_FILE, parse_dates=["timestamp"])

    # Select seven consecutive days
    start_date = pd.Timestamp("2025-01-01")
    end_date = start_date + pd.Timedelta(days=7)

    zone_data = zone_data[
        (zone_data["timestamp"] >= start_date) &
        (zone_data["timestamp"] < end_date)
    ]

    supply_data = supply_data[
        (supply_data["timestamp"] >= start_date) &
        (supply_data["timestamp"] < end_date)
    ]

    if zone_data.empty or supply_data.empty:
        raise ValueError("No data found for the selected evaluation period.")

    supply_lookup = supply_data.set_index(
        "timestamp"
    )["total_available_supply_kwh"].to_dict()

    results = []

    for timestamp, group in zone_data.groupby("timestamp"):

        demand = dict(zip(group["zone"], group["demand_kwh"]))

        if set(demand) != set(ZONE_PRIORITY):
            raise ValueError(f"Incomplete zone data at {timestamp}")

        available_supply = float(supply_lookup[timestamp])

        usable_supply = max(
            0.0,
            min(available_supply, MAXIMUM_SUPPLY) - RESERVED_SUPPLY
        )

        # Method 1: Proportional
        proportional = proportional_allocation(demand, usable_supply)

        # Method 2: Priority-based
        priority = priority_allocation(demand, usable_supply)

        # Method 3: Proposed optimization
        proposed_result = optimize_energy_allocation(
            demand,
            available_supply
        )

        if proposed_result["status"] != "Optimal":
            raise RuntimeError(
                f"Optimization failed at {timestamp}: "
                f"{proposed_result['status']}"
            )

        proposed = {
            zone: values["allocated_kwh"]
            for zone, values in proposed_result["zones"].items()
        }

        methods = {
            "Proportional": proportional,
            "Priority-Based": priority,
            "AI + Optimization": proposed
        }

        for method_name, allocation in methods.items():
            results.extend(
                evaluate_allocation(
                    timestamp,
                    method_name,
                    demand,
                    allocation
                )
            )

    results_df = pd.DataFrame(results)

    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    detail_file = REPORT_DIR / "multi_day_evaluation_details.csv"
    results_df.to_csv(detail_file, index=False)

    summary = results_df.groupby("method").agg(
        total_demand_kwh=("demand_kwh", "sum"),
        total_allocated_kwh=("allocated_kwh", "sum"),
        total_unmet_demand_kwh=("unmet_demand_kwh", "sum"),
        average_satisfaction_percentage=("satisfaction_percentage", "mean")
    ).reset_index()

    summary["overall_demand_satisfaction_percentage"] = (
        summary["total_allocated_kwh"] /
        summary["total_demand_kwh"] * 100
    ).round(2)

    summary_file = REPORT_DIR / "multi_day_evaluation_summary.csv"
    summary.to_csv(summary_file, index=False)

    print("\nEvaluation period: 7 days")
    print("Hours evaluated:", results_df["timestamp"].nunique())
    print("Total records:", len(results_df))

    print("\n========== PERFORMANCE SUMMARY ==========")
    print(summary.round(2).to_string(index=False))

    print("\nDetailed results:", detail_file)
    print("Summary results:", summary_file)

    print("\nMULTI-DAY EVALUATION COMPLETED SUCCESSFULLY")


if __name__ == "__main__":
    run_multi_day_evaluation()
