
import pandas as pd
from pathlib import Path

from backend.optimization.load_optimizer import optimize_energy_allocation

# Project paths
BASE_DIR = Path(__file__).resolve().parents[2]
PREDICTION_FILE = BASE_DIR / "reports" / "next_hour_predictions.csv"
SUPPLY_FILE = BASE_DIR / "datasets" / "system_supply_dataset.csv"
REPORT_DIR = BASE_DIR / "reports"

EXPECTED_ZONES = [
    "Hospital",
    "Emergency Centre",
    "Residential",
    "Commercial",
    "Industrial"
]


def run_forecast_optimization():

    print("\n========== AI-POWERED ENERGY OPTIMIZATION ==========")

    # 1. Check required files
    if not PREDICTION_FILE.exists():
        raise FileNotFoundError("Demand prediction report not found.")

    if not SUPPLY_FILE.exists():
        raise FileNotFoundError("System supply dataset not found.")

    # 2. Load predicted demand
    predictions = pd.read_csv(
        PREDICTION_FILE,
        parse_dates=["prediction_timestamp"]
    )

    if predictions["zone"].duplicated().any():
        raise ValueError("Duplicate zone predictions found.")

    demand_data = dict(zip(
        predictions["zone"],
        predictions["predicted_demand_kwh"]
    ))

    if set(demand_data) != set(EXPECTED_ZONES):
        raise ValueError("Predictions must contain exactly all five zones.")

    print("\nAI-predicted demand:")
    for zone, demand in demand_data.items():
        print(f"{zone}: {demand:.2f} kWh")

    # 3. Load latest known system supply
    supply_data = pd.read_csv(
        SUPPLY_FILE,
        parse_dates=["timestamp"]
    )

    latest_supply_record = supply_data.sort_values(
        "timestamp"
    ).iloc[-1]

    available_supply = float(
        latest_supply_record["total_available_supply_kwh"]
    )

    print("\nLatest available supply:", round(available_supply, 2), "kWh")

    # 4. Optimize energy allocation using AI predictions
    result = optimize_energy_allocation(
        demand_data,
        available_supply
    )
    
    # 5. Display optimization results
    print("\n========== OPTIMIZATION RESULTS ==========")

    total_predicted_demand = sum(demand_data.values())

    print("Solver status:", result["status"])
    print("Total predicted demand:", round(total_predicted_demand, 2), "kWh")
    print("Available supply:", round(result["available_supply_kwh"], 2), "kWh")
    print("Reserved supply:", round(result["reserved_supply_kwh"], 2), "kWh")
    print("Usable supply:", round(result["usable_supply_kwh"], 2), "kWh")
    print("Total allocated energy:", round(result["total_allocated_kwh"], 2), "kWh")
    print("Total unmet demand:", round(result["total_unmet_demand_kwh"], 2), "kWh")
    # 6. Prepare allocation report
    report = []

    prediction_timestamp = predictions["prediction_timestamp"].iloc[0]

    for zone, values in result["zones"].items():

        report.append({
            "prediction_timestamp": prediction_timestamp,
            "zone": zone,
            "predicted_demand_kwh": values["demand_kwh"],
            "allocated_kwh": values["allocated_kwh"],
            "unmet_demand_kwh": values["unmet_demand_kwh"],
            "satisfaction_percentage": values["satisfaction_percentage"],
            "available_supply_kwh": result["available_supply_kwh"],
            "solver_status": result["status"]
        })

    # 7. Save report
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    output_file = REPORT_DIR / "forecast_allocation_results.csv"

    pd.DataFrame(report).to_csv(output_file, index=False)

    print("\n========== ZONE-WISE ALLOCATION ==========")
    print(pd.DataFrame(report).to_string(index=False))

    print("\nAllocation report saved to:")
    print(output_file)

    print("\nAI-POWERED OPTIMIZATION COMPLETED SUCCESSFULLY")


if __name__ == "__main__":
    run_forecast_optimization()
