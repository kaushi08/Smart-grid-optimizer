
import pandas as pd
from pathlib import Path

from backend.optimization.load_optimizer import optimize_energy_allocation


# Project directories
BASE_DIR = Path(__file__).resolve().parents[2]
DATASET_DIR = BASE_DIR / "datasets"
REPORT_DIR = BASE_DIR / "reports"

ZONE_FILE = DATASET_DIR / "smart_grid_dataset.csv"
SUPPLY_FILE = DATASET_DIR / "system_supply_dataset.csv"

# First test: simulate one day
SIMULATION_DATE = "2025-01-01"


def run_simulation():

    print("\n========== SMART GRID SIMULATION ==========")

    # Check input files
    if not ZONE_FILE.exists():
        raise FileNotFoundError(f"Missing file: {ZONE_FILE}")

    if not SUPPLY_FILE.exists():
        raise FileNotFoundError(f"Missing file: {SUPPLY_FILE}")

    # Load datasets
    zone_data = pd.read_csv(ZONE_FILE, parse_dates=["timestamp"])
    supply_data = pd.read_csv(SUPPLY_FILE, parse_dates=["timestamp"])

    # Select the requested simulation date
    selected_date = pd.Timestamp(SIMULATION_DATE).date()

    zone_day = zone_data[
        zone_data["timestamp"].dt.date == selected_date
    ].copy()

    supply_day = supply_data[
        supply_data["timestamp"].dt.date == selected_date
    ].copy()

    if len(zone_day) != 24 * 5:
        raise ValueError(
            f"Expected 120 zone records, found {len(zone_day)}"
        )

    if len(supply_day) != 24:
        raise ValueError(
            f"Expected 24 supply records, found {len(supply_day)}"
        )

    # Create timestamp-to-supply lookup
    supply_lookup = supply_day.set_index(
        "timestamp"
    )["total_available_supply_kwh"].to_dict()

    results = []

    # Process each hour
    for timestamp, group in zone_day.groupby("timestamp"):

        demand_data = dict(
            zip(group["zone"], group["demand_kwh"])
        )

        available_supply = float(supply_lookup[timestamp])

        allocation_result = optimize_energy_allocation(
            demand_data,
            available_supply
        )

        # Store zone-wise results
        for zone, values in allocation_result["zones"].items():

            results.append({
                "timestamp": timestamp,
                "zone": zone,
                "demand_kwh": values["demand_kwh"],
                "allocated_kwh": values["allocated_kwh"],
                "unmet_demand_kwh": values["unmet_demand_kwh"],
                "satisfaction_percentage":
                    values["satisfaction_percentage"],
                "available_supply_kwh":
                    allocation_result["available_supply_kwh"],
                "total_allocated_kwh":
                    allocation_result["total_allocated_kwh"],
                "solver_status": allocation_result["status"]
            })

    # Convert results to DataFrame
    results_df = pd.DataFrame(results)

    # Save simulation output
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    output_file = REPORT_DIR / "simulation_results.csv"

    results_df.to_csv(output_file, index=False)

    # Display summary
    print("\nSimulation date:", SIMULATION_DATE)
    print("Hours simulated:", results_df["timestamp"].nunique())
    print("Total zone records:", len(results_df))

    print(
        "Total demand:",
        round(results_df["demand_kwh"].sum(), 2),
        "kWh"
    )

    print(
        "Total allocated:",
        round(results_df["allocated_kwh"].sum(), 2),
        "kWh"
    )

    print(
        "Total unmet demand:",
        round(results_df["unmet_demand_kwh"].sum(), 2),
        "kWh"
    )

    print("\nAverage zone satisfaction:")

    print(
        results_df.groupby("zone")[
            "satisfaction_percentage"
        ].mean().round(2)
    )

    print("\nSimulation output saved to:")
    print(output_file)

    print("\nSMART GRID SIMULATION COMPLETED SUCCESSFULLY")


if __name__ == "__main__":
    run_simulation()
