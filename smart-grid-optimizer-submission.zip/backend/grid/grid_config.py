
# SMART GRID CONFIGURATION

PROJECT_NAME = "AI-Powered Intelligent Load Balancing System"

ENERGY_UNIT = "kWh"

# Total energy supply available to the grid per hour
GRID_CONFIG = {
    "maximum_grid_supply_kwh": 1000,
    "minimum_grid_reserve_kwh": 50,
    "simulation_interval_minutes": 60
}

# Individual zone configuration
ZONE_CONFIG = {
    "Hospital": {
        "priority": 1,
        "priority_name": "Critical",
        "minimum_supply_fraction": 0.90,
        "maximum_capacity_kwh": 200
    },

    "Emergency Centre": {
        "priority": 1,
        "priority_name": "Critical",
        "minimum_supply_fraction": 0.90,
        "maximum_capacity_kwh": 120
    },

    "Residential": {
        "priority": 2,
        "priority_name": "High",
        "minimum_supply_fraction": 0.60,
        "maximum_capacity_kwh": 250
    },

    "Commercial": {
        "priority": 3,
        "priority_name": "Medium",
        "minimum_supply_fraction": 0.40,
        "maximum_capacity_kwh": 200
    },

    "Industrial": {
        "priority": 3,
        "priority_name": "Medium",
        "minimum_supply_fraction": 0.50,
        "maximum_capacity_kwh": 300
    }
}


def get_zone_names():
    return list(ZONE_CONFIG.keys())


def get_zone_configuration(zone_name):
    if zone_name not in ZONE_CONFIG:
        raise ValueError(f"Unknown grid zone: {zone_name}")

    return ZONE_CONFIG[zone_name]


def display_grid_configuration():
    print("\n========== SMART GRID CONFIGURATION ==========")

    print("\nGrid settings:")
    for key, value in GRID_CONFIG.items():
        print(f"{key}: {value}")

    print("\nZone settings:")
    for zone, config in ZONE_CONFIG.items():
        print(f"\n{zone}")
        for key, value in config.items():
            print(f"  {key}: {value}")


if __name__ == "__main__":
    display_grid_configuration()
