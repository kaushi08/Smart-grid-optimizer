
import pulp

from backend.grid.grid_config import GRID_CONFIG, ZONE_CONFIG


def optimize_energy_allocation(demand_data, available_supply_kwh):
    """
    Allocate available energy across grid zones using linear programming.

    demand_data example:
    {
        "Hospital": 120,
        "Emergency Centre": 70,
        "Residential": 180,
        "Commercial": 140,
        "Industrial": 220
    }
    """

    if available_supply_kwh < 0:
        raise ValueError("Available supply cannot be negative.")

    if set(demand_data) != set(ZONE_CONFIG):
        raise ValueError("Demand data must contain exactly the five configured zones.")

    for zone, demand in demand_data.items():
        if demand < 0:
            raise ValueError(f"Demand for {zone} cannot be negative.")

    # Respect the grid's maximum supply and keep the required reserve.
    capped_supply = min(
        float(available_supply_kwh),
        GRID_CONFIG["maximum_grid_supply_kwh"]
    )

    usable_supply = max(
        0.0,
        capped_supply - GRID_CONFIG["minimum_grid_reserve_kwh"]
    )

    # Create the optimization problem.
    model = pulp.LpProblem(
        "Smart_Grid_Energy_Optimization",
        pulp.LpMinimize
    )

    # Decision variables.
    allocation = {
        zone: pulp.LpVariable(
            f"allocation_{index}",
            lowBound=0,
            cat="Continuous"
        )
        for index, zone in enumerate(ZONE_CONFIG)
    }

    unmet_demand = {
        zone: pulp.LpVariable(
            f"unmet_demand_{index}",
            lowBound=0,
            cat="Continuous"
        )
        for index, zone in enumerate(ZONE_CONFIG)
    }

    minimum_shortfall = {
        zone: pulp.LpVariable(
            f"minimum_shortfall_{index}",
            lowBound=0,
            cat="Continuous"
        )
        for index, zone in enumerate(ZONE_CONFIG)
    }

    # Higher weights protect higher-priority zones.
    priority_weights = {
        1: 100,
        2: 20,
        3: 5
    }

    # Objective: minimize weighted unmet demand and
    # strongly penalize failure to meet minimum requirements.
    model += pulp.lpSum(
        priority_weights[ZONE_CONFIG[zone]["priority"]]
        * unmet_demand[zone]
        + 1000 * minimum_shortfall[zone]
        for zone in ZONE_CONFIG
    )

    # Each zone's allocation plus unmet demand must equal demand.
    for zone, config in ZONE_CONFIG.items():
        demand = float(demand_data[zone])

        model += (
            allocation[zone] + unmet_demand[zone] == demand,
            f"demand_balance_{zone}"
        )

        # A zone cannot receive more than its configured capacity.
        model += (
            allocation[zone] <= config["maximum_capacity_kwh"],
            f"capacity_limit_{zone}"
        )

        # Try to meet the zone's minimum supply requirement.
        required_minimum = (
            demand * config["minimum_supply_fraction"]
        )

        model += (
            allocation[zone] + minimum_shortfall[zone]
            >= required_minimum,
            f"minimum_supply_{zone}"
        )

        model += (
            minimum_shortfall[zone] <= required_minimum,
            f"shortfall_limit_{zone}"
        )

    # Total allocation cannot exceed usable grid supply.
    model += (
        pulp.lpSum(allocation.values()) <= usable_supply,
        "total_supply_limit"
    )

    # Solve the optimization problem.
    solver = pulp.PULP_CBC_CMD(msg=False)
    model.solve(solver)

    status = pulp.LpStatus[model.status]

    if status != "Optimal":
        raise RuntimeError(f"Optimization failed. Solver status: {status}")

    # Prepare results.
    results = {}

    for zone in ZONE_CONFIG:
        allocated = pulp.value(allocation[zone])
        unmet = pulp.value(unmet_demand[zone])
        shortfall = pulp.value(minimum_shortfall[zone])
        demand = float(demand_data[zone])

        satisfaction = (
            (allocated / demand) * 100 if demand > 0 else 100.0
        )

        results[zone] = {
            "demand_kwh": round(demand, 2),
            "allocated_kwh": round(allocated, 2),
            "unmet_demand_kwh": round(unmet, 2),
            "minimum_shortfall_kwh": round(shortfall, 2),
            "satisfaction_percentage": round(satisfaction, 2)
        }

    total_allocated = sum(
        item["allocated_kwh"] for item in results.values()
    )

    total_unmet = sum(
        item["unmet_demand_kwh"] for item in results.values()
    )

    return {
        "status": status,
        "available_supply_kwh": round(capped_supply, 2),
        "reserved_supply_kwh": round(
            capped_supply - usable_supply, 2
        ),
        "usable_supply_kwh": round(usable_supply, 2),
        "total_allocated_kwh": round(total_allocated, 2),
        "total_unmet_demand_kwh": round(total_unmet, 2),
        "zones": results
    }


# Test the optimizer independently.
if __name__ == "__main__":

    sample_demand = {
        "Hospital": 120,
        "Emergency Centre": 70,
        "Residential": 180,
        "Commercial": 140,
        "Industrial": 220
    }

    available_supply = 700

    output = optimize_energy_allocation(
        sample_demand,
        available_supply
    )

    print("\n========== SMART GRID OPTIMIZATION ==========")

    print("Solver status:", output["status"])
    print("Available supply:", output["available_supply_kwh"], "kWh")
    print("Reserved supply:", output["reserved_supply_kwh"], "kWh")
    print("Usable supply:", output["usable_supply_kwh"], "kWh")
    print("Total allocated:", output["total_allocated_kwh"], "kWh")
    print("Total unmet demand:", output["total_unmet_demand_kwh"], "kWh")

    print("\nZONE-WISE ALLOCATION")

    for zone, values in output["zones"].items():
        print(f"\n{zone}")
        for key, value in values.items():
            print(f"  {key}: {value}")
