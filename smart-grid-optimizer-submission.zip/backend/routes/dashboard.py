
from pathlib import Path

import pandas as pd
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from backend.config import REPORT_DIR
from backend.optimization.load_optimizer import optimize_energy_allocation


router = APIRouter()

PREDICTION_FILE = REPORT_DIR / "next_hour_predictions.csv"
SIMULATION_FILE = REPORT_DIR / "simulation_results.csv"


class OptimizationRequest(BaseModel):
    available_supply_kwh: float = Field(ge=0)


# Dashboard API
@router.get("/dashboard")
def get_dashboard():
    if not SIMULATION_FILE.exists():
        raise HTTPException(
            status_code=404,
            detail="Simulation results file not found."
        )

    df = pd.read_csv(SIMULATION_FILE)

    if df.empty:
        raise HTTPException(
            status_code=404,
            detail="Simulation results are empty."
        )

    latest_timestamp = df["timestamp"].max()
    latest_data = df[df["timestamp"] == latest_timestamp]

    total_demand = round(float(latest_data["demand_kwh"].sum()), 2)
    total_allocated = round(float(latest_data["allocated_kwh"].sum()), 2)
    total_unmet = round(float(latest_data["unmet_demand_kwh"].sum()), 2)

    satisfaction = (
        round((total_allocated / total_demand) * 100, 2)
        if total_demand > 0 else 0
    )

    zones = []

    for _, row in latest_data.iterrows():
        demand = float(row["demand_kwh"])
        allocated = float(row["allocated_kwh"])
        unmet = float(row["unmet_demand_kwh"])

        zones.append({
            "name": row["zone"],
            "demand_kwh": round(demand, 2),
            "allocated_kwh": round(allocated, 2),
            "unmet_demand_kwh": round(unmet, 2),
            "satisfaction_percentage": round(
                (allocated / demand) * 100 if demand > 0 else 0, 2
            )
        })

    return {
        "timestamp": str(latest_timestamp),
        "total_demand_kwh": total_demand,
        "total_allocated_kwh": total_allocated,
        "total_unmet_demand_kwh": total_unmet,
        "demand_satisfaction_percentage": satisfaction,
        "zones": zones
    }


# AI Demand Prediction API
@router.get("/predictions")
def get_predictions():
    if not PREDICTION_FILE.exists():
        raise HTTPException(
            status_code=404,
            detail="Demand prediction file not found. Run the prediction script first."
        )

    df = pd.read_csv(PREDICTION_FILE)

    required_columns = ["zone", "predicted_demand_kwh"]

    if not all(column in df.columns for column in required_columns):
        raise HTTPException(
            status_code=500,
            detail="Prediction CSV is missing required columns."
        )

    if df.empty:
        raise HTTPException(
            status_code=404,
            detail="No prediction records found."
        )

    predictions = []

    for _, row in df.iterrows():
        predictions.append({
            "zone": str(row["zone"]),
            "predicted_demand_kwh": round(
                float(row["predicted_demand_kwh"]), 2
            )
        })

    return {
        "model": "XGBoost",
        "prediction_type": "Next-hour demand forecast",
        "total_zones": len(predictions),
        "predictions": predictions
    }


# Intelligent Optimization API
@router.post("/optimize")
def run_optimization(request: OptimizationRequest):
    if not PREDICTION_FILE.exists():
        raise HTTPException(
            status_code=404,
            detail="Demand predictions file not found."
        )

    df = pd.read_csv(PREDICTION_FILE)

    required_columns = ["zone", "predicted_demand_kwh"]

    if not all(column in df.columns for column in required_columns):
        raise HTTPException(
            status_code=500,
            detail="Prediction CSV is missing required columns."
        )

    if df["zone"].duplicated().any():
        raise HTTPException(
            status_code=400,
            detail="Duplicate zone records found."
        )

    demand_data = dict(
        zip(df["zone"], df["predicted_demand_kwh"])
    )

    result = optimize_energy_allocation(
        demand_data=demand_data,
        available_supply_kwh=request.available_supply_kwh
    )

    return {
        "status": result["status"],
        "predicted_total_demand_kwh": round(
            float(df["predicted_demand_kwh"].sum()), 2
        ),
        "available_supply_kwh": result["available_supply_kwh"],
        "usable_supply_kwh": result["usable_supply_kwh"],
        "total_allocated_kwh": result["total_allocated_kwh"],
        "total_unmet_demand_kwh": result["total_unmet_demand_kwh"],
        "zones": result["zones"]
    }
