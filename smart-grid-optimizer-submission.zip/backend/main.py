
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.config import PROJECT_NAME, ZONES
from backend.routes.dashboard import router as dashboard_router
from backend.grid.grid_config import ZONE_CONFIG


app = FastAPI(
    title=PROJECT_NAME,
    description="AI-Powered Intelligent Load Balancing and Energy Distribution System",
    version="1.0.0"
)
# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5175",
        "http://127.0.0.1:5175"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


# Home Endpoint
@app.get("/")
def home():
    return {
        "message": "Smart Grid System is running",
        "project": PROJECT_NAME
    }


# Basic Zone Endpoint
@app.get("/zones")
def get_zones():
    return {
        "total_zones": len(ZONES),
        "zones": ZONES
    }


# Detailed Zone Configuration Endpoint
@app.get("/zone-details")
def get_zone_details():
    return {
        "total_zones": len(ZONE_CONFIG),
        "zones": [
            {
                "name": name,
                **details
            }
            for name, details in ZONE_CONFIG.items()
        ]
    }


# Dashboard and Optimization API Routes
app.include_router(dashboard_router, prefix="/api")
