
import json
import pandas as pd
from pathlib import Path
from xgboost import XGBRegressor

# Project paths
BASE_DIR = Path(__file__).resolve().parents[2]

DATASET_FILE = BASE_DIR / "datasets" / "smart_grid_dataset.csv"
MODEL_FILE = BASE_DIR / "models" / "demand_forecasting_model.json"
FEATURE_FILE = BASE_DIR / "models" / "model_features.json"

REPORT_DIR = BASE_DIR / "reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def predict_next_hour_demand():

    print("\n========== NEXT-HOUR DEMAND PREDICTION ==========")

    # 1. Check required files
    for file in [DATASET_FILE, MODEL_FILE, FEATURE_FILE]:
        if not file.exists():
            raise FileNotFoundError(f"Required file not found: {file}")

    # 2. Load dataset
    data = pd.read_csv(
        DATASET_FILE,
        parse_dates=["timestamp"]
    )

    data = data.sort_values(
        ["zone", "timestamp"]
    ).reset_index(drop=True)

    print("\nHistorical dataset loaded:", len(data), "records")

    # 3. Create historical features
    grouped = data.groupby("zone", sort=False)

    data["demand_lag_1"] = grouped["demand_kwh"].shift(1)
    data["demand_lag_24"] = grouped["demand_kwh"].shift(24)
    data["demand_lag_168"] = grouped["demand_kwh"].shift(168)

    data["rolling_mean_24"] = (
        data.groupby("zone")["demand_kwh"]
        .transform(lambda series: series.rolling(24).mean())
    )

    # 4. Get latest record for each zone
    latest_data = (
        data.groupby("zone", sort=False)
        .tail(1)
        .copy()
    )

    if latest_data["zone"].nunique() != 5:
        raise ValueError("Expected exactly five grid zones.")

    # 5. Calculate next-hour calendar features
    next_timestamp = latest_data["timestamp"] + pd.Timedelta(hours=1)

    latest_data["next_hour"] = next_timestamp.dt.hour
    latest_data["next_day_of_week"] = next_timestamp.dt.dayofweek
    latest_data["next_month"] = next_timestamp.dt.month
    latest_data["next_is_weekend"] = (
        next_timestamp.dt.dayofweek >= 5
    ).astype(int)

    # 6. Create zone one-hot encoded columns
    latest_data = pd.get_dummies(
        latest_data,
        columns=["zone"],
        dtype=int
    )

    # 7. Load model feature order
    with open(FEATURE_FILE, "r") as file:
        feature_columns = json.load(file)

    # Add any missing zone columns as zero
    for column in feature_columns:
        if column not in latest_data.columns:
            latest_data[column] = 0

    X_input = latest_data[feature_columns]

    # 8. Load trained model
    model = XGBRegressor()
    model.load_model(str(MODEL_FILE))

    print("\nTrained XGBoost model loaded.")

    # 9. Predict next-hour demand
    predictions = model.predict(X_input)

    # Demand cannot be negative
    predictions = predictions.clip(min=0)

    # 10. Prepare prediction results
    results = pd.DataFrame({
        "prediction_timestamp": next_timestamp.values,
        "zone": latest_data[
            [column for column in latest_data.columns
             if column.startswith("zone_")]
        ].idxmax(axis=1).str.replace("zone_", "", regex=False).values,
        "current_demand_kwh": latest_data["demand_kwh"].values,
        "predicted_demand_kwh": predictions.round(2)
    })

    # 11. Save results
    output_file = REPORT_DIR / "next_hour_predictions.csv"
    results.to_csv(output_file, index=False)
    print("\nPrediction report saved to:")
    print(output_file)
    print("File exists:", output_file.exists())

    # 12. Display results
    print("\n========== PREDICTED ENERGY DEMAND ==========")

    print(results.to_string(index=False))

    print("\nTotal predicted demand:",
          round(results["predicted_demand_kwh"].sum(), 2), "kWh")

    print("\nPrediction results saved to:")
    print(output_file)

    print("\nNEXT-HOUR PREDICTION COMPLETED SUCCESSFULLY")


if __name__ == "__main__":
    predict_next_hour_demand()
