
import json
import pandas as pd
import numpy as np

from pathlib import Path
from xgboost import XGBRegressor

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

# Project paths
BASE_DIR = Path(__file__).resolve().parents[2]

DATASET_FILE = BASE_DIR / "datasets" / "smart_grid_dataset.csv"
MODEL_DIR = BASE_DIR / "models"

MODEL_DIR.mkdir(parents=True, exist_ok=True)


def train_demand_model():

    print("\n========== XGBOOST DEMAND PREDICTION ==========")

    # 1. Load historical dataset
    if not DATASET_FILE.exists():
        raise FileNotFoundError(
            f"Dataset not found: {DATASET_FILE}"
        )

    data = pd.read_csv(
        DATASET_FILE,
        parse_dates=["timestamp"]
    )

    data = data.sort_values(
        ["zone", "timestamp"]
    ).reset_index(drop=True)

    print("\nDataset loaded:", len(data), "records")

    # 2. Create next-hour prediction target
    grouped = data.groupby("zone", sort=False)

    data["target_next_hour"] = (
        grouped["demand_kwh"].shift(-1)
    )

    # 3. Create historical demand features
    data["demand_lag_1"] = (
        grouped["demand_kwh"].shift(1)
    )

    data["demand_lag_24"] = (
        grouped["demand_kwh"].shift(24)
    )

    data["demand_lag_168"] = (
        grouped["demand_kwh"].shift(168)
    )

    data["rolling_mean_24"] = (
        data.groupby("zone")["demand_kwh"]
        .transform(
            lambda series: series.rolling(24).mean()
        )
    )

    # 4. Create next-hour calendar features
    next_timestamp = (
        data["timestamp"] + pd.Timedelta(hours=1)
    )

    data["next_hour"] = next_timestamp.dt.hour
    data["next_day_of_week"] = next_timestamp.dt.dayofweek
    data["next_month"] = next_timestamp.dt.month

    data["next_is_weekend"] = (
        next_timestamp.dt.dayofweek >= 5
    ).astype(int)

    # 5. Prepare input features
    feature_columns = [
        "hour",
        "day_of_week",
        "month",
        "is_weekend",
        "temperature_c",
        "minimum_supply_fraction",
        "demand_kwh",
        "demand_lag_1",
        "demand_lag_24",
        "demand_lag_168",
        "rolling_mean_24",
        "next_hour",
        "next_day_of_week",
        "next_month",
        "next_is_weekend"
    ]

    # Encode zone names
    data = pd.get_dummies(
        data,
        columns=["zone"],
        dtype=int
    )

    zone_columns = [
        column for column in data.columns
        if column.startswith("zone_")
    ]

    feature_columns.extend(zone_columns)

    # Remove incomplete historical records
    data = data.dropna(
        subset=feature_columns + ["target_next_hour"]
    ).copy()

    # 6. Chronological train-test split
    unique_timestamps = np.sort(
        data["timestamp"].unique()
    )

    split_index = int(
        len(unique_timestamps) * 0.80
    )

    split_timestamp = unique_timestamps[split_index]

    train_data = data[
        data["timestamp"] < split_timestamp
    ]

    test_data = data[
        data["timestamp"] >= split_timestamp
    ]

    X_train = train_data[feature_columns]
    y_train = train_data["target_next_hour"]

    X_test = test_data[feature_columns]
    y_test = test_data["target_next_hour"]

    print("\nTraining records:", len(X_train))
    print("Testing records:", len(X_test))
    print("Training cutoff:", split_timestamp)

    # 7. Create XGBoost model
    model = XGBRegressor(
        objective="reg:squarederror",
        n_estimators=300,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        n_jobs=-1,
        eval_metric="rmse"
    )

    # 8. Train model
    print("\nTraining XGBoost model...")

    model.fit(X_train, y_train)

    print("Model training completed.")

    # 9. Evaluate model
    predictions = model.predict(X_test)

    mae = mean_absolute_error(
        y_test,
        predictions
    )

    rmse = np.sqrt(
        mean_squared_error(y_test, predictions)
    )

    r2 = r2_score(
        y_test,
        predictions
    )

    print("\n========== MODEL EVALUATION ==========")

    print("MAE:", round(mae, 4))
    print("RMSE:", round(rmse, 4))
    print("R2 Score:", round(r2, 4))

    # 10. Save model in native XGBoost JSON format
    model_file = (
        MODEL_DIR / "demand_forecasting_model.json"
    )

    model.save_model(str(model_file))

    # Save feature information separately
    feature_file = MODEL_DIR / "model_features.json"

    with open(feature_file, "w") as file:
        json.dump(feature_columns, file, indent=4)

    print("\nModel saved successfully:")
    print(model_file)

    print("\nFeature information saved:")
    print(feature_file)

    # 11. Save prediction evaluation
    prediction_results = test_data[
        ["timestamp"]
    ].copy()

    prediction_results["actual_next_hour_demand"] = (
        y_test.to_numpy()
    )

    prediction_results["predicted_next_hour_demand"] = (
        predictions
    )

    prediction_file = (
        MODEL_DIR / "prediction_evaluation.csv"
    )

    prediction_results.to_csv(
        prediction_file,
        index=False
    )

    print("\nPrediction evaluation saved:")
    print(prediction_file)

    print("\nXGBOOST TRAINING COMPLETED SUCCESSFULLY")


if __name__ == "__main__":
    train_demand_model()
