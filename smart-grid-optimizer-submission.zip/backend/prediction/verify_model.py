
import json
from pathlib import Path
from xgboost import XGBRegressor

# Project paths
BASE_DIR = Path(__file__).resolve().parents[2]
MODEL_DIR = BASE_DIR / "models"

MODEL_FILE = MODEL_DIR / "demand_forecasting_model.json"
FEATURE_FILE = MODEL_DIR / "model_features.json"

print("\n========== MODEL VERIFICATION ==========")

# Check files
if not MODEL_FILE.exists():
    raise FileNotFoundError(
        "Trained XGBoost JSON model not found. "
        "Run train_demand_model.py first."
    )

if not FEATURE_FILE.exists():
    raise FileNotFoundError(
        "Model feature file not found."
    )

# Load trained XGBoost model
model = XGBRegressor()
model.load_model(str(MODEL_FILE))

# Load feature names
with open(FEATURE_FILE, "r") as file:
    features = json.load(file)

# Display model information
print("\nModel loaded successfully!")
print("Model type:", type(model).__name__)
print("Number of input features:", len(features))

print("\nFeature names:")

for feature in features:
    print("-", feature)

print("\nMODEL VERIFICATION COMPLETED SUCCESSFULLY")
