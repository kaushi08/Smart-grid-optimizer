
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

import { Bar, Doughnut } from "react-chartjs-2";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
);

function Charts({ zones }) {
  if (!zones || zones.length === 0) {
    return <p>No chart data available.</p>;
  }

  const labels = zones.map((zone) => zone.name);

  const demandData = {
    labels,
    datasets: [
      {
        label: "Predicted Demand (kWh)",
        data: zones.map((zone) => zone.demand_kwh),
      },
      {
        label: "Allocated Energy (kWh)",
        data: zones.map((zone) => zone.allocated_kwh),
      },
    ],
  };

  const allocationData = {
    labels,
    datasets: [
      {
        label: "Allocated Energy (kWh)",
        data: zones.map((zone) => zone.allocated_kwh),
      },
    ],
  };

  const satisfactionData = {
    labels,
    datasets: [
      {
        label: "Demand Satisfaction (%)",
        data: zones.map((zone) => zone.satisfaction_percentage),
      },
    ],
  };

  const unmetData = {
    labels,
    datasets: [
      {
        label: "Unmet Demand (kWh)",
        data: zones.map((zone) => zone.unmet_demand_kwh),
      },
    ],
  };

  return (
    <section className="charts-section">
      <h2>Energy Analytics & Visualization</h2>

      <div className="chart-container">
        <h3>Demand vs Allocated Energy</h3>
        <Bar data={demandData} />
      </div>

      <div className="chart-container">
        <h3>Zone-wise Energy Distribution</h3>
        <Doughnut data={allocationData} />
      </div>

      <div className="chart-container">
        <h3>Demand Satisfaction</h3>
        <Bar data={satisfactionData} />
      </div>

      <div className="chart-container">
        <h3>Zone-wise Unmet Demand</h3>
        <Bar data={unmetData} />
      </div>
    </section>
  );
}

export default Charts;
