
import { useState } from "react";

function Optimization() {
  const [supply, setSupply] = useState("700");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const runOptimization = async () => {
    setLoading(true);
    setError("");
    setResult(null);

    try {
      const response = await fetch("http://127.0.0.1:8000/api/optimize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          available_supply_kwh: Number(supply),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Optimization failed.");
      }

      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="optimization-page">
      <h1>Intelligent Energy Optimization</h1>
      <p>Run AI-based demand allocation using the optimization engine.</p>

      <div className="optimization-input">
        <label>Available Grid Supply (kWh)</label>
        <input
          type="number"
          min="0"
          value={supply}
          onChange={(e) => setSupply(e.target.value)}
        />

        <button
          onClick={runOptimization}
          disabled={loading || supply === "" || Number(supply) < 0}
        >
          {loading ? "Optimizing..." : "Run Optimization"}
        </button>
      </div>

      {error && <p className="error">{error}</p>}

      {result && (
        <div className="optimization-results">
          <h2>Optimization Results</h2>
          <p><strong>Status:</strong> {result.status}</p>
          <p><strong>Predicted Demand:</strong> {result.predicted_demand_kwh} kWh</p>
          <p><strong>Available Supply:</strong> {result.available_supply_kwh} kWh</p>
          <p><strong>Usable Supply:</strong> {result.usable_supply_kwh} kWh</p>
          <p><strong>Allocated Energy:</strong> {result.total_allocated_kwh} kWh</p>
          <p><strong>Unmet Demand:</strong> {result.total_unmet_demand_kwh} kWh</p>

          <h3>Zone-wise Allocation</h3>
          <table>
            <thead>
              <tr>
                <th>Zone</th>
                <th>Demand</th>
                <th>Allocated</th>
                <th>Unmet</th>
                <th>Satisfaction</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(result.zones).map(([zone, values]) => (
                <tr key={zone}>
                  <td>{zone}</td>
                  <td>{values.demand_kwh} kWh</td>
                  <td>{values.allocated_kwh} kWh</td>
                  <td>{values.unmet_demand_kwh} kWh</td>
                  <td>{values.satisfaction_percentage}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default Optimization;
