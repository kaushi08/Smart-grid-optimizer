
import { useEffect, useState } from "react";

const CRITICAL_ZONES = ["Hospital", "Emergency Centre"];

function Alerts() {
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/dashboard")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Unable to fetch alert information.");
        }
        return response.json();
      })
      .then((data) => {
        setDashboard(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  const alerts = dashboard
    ? dashboard.zones.flatMap((zone) => {
        const items = [];

        if (zone.unmet_demand_kwh > 0) {
          items.push({
            title: `${zone.name}: Unmet energy demand`,
            message: `${zone.unmet_demand_kwh} kWh of demand is unmet.`,
            severity: CRITICAL_ZONES.includes(zone.name)
              ? "Critical"
              : "Warning"
          });
        }

        if (
          CRITICAL_ZONES.includes(zone.name) &&
          zone.satisfaction_percentage < 100
        ) {
          items.push({
            title: `${zone.name}: Critical service attention`,
            message: `Energy satisfaction is ${zone.satisfaction_percentage}%.`,
            severity: "Critical"
          });
        }

        return items;
      })
    : [];

  return (
    <div className="alerts-page">
      <h2>Energy Alerts and Notifications</h2>
      <p>Monitor simulated energy shortages and critical-zone conditions.</p>

      {loading && <p>Loading alerts...</p>}
      {error && <p className="error">{error}</p>}

      {dashboard && (
        <>
          <div className="alert-summary">
            <div className="alert-summary-card">
              <h3>Total Alerts</h3>
              <h2>{alerts.length}</h2>
            </div>

            <div className="alert-summary-card">
              <h3>Critical Alerts</h3>
              <h2>
                {alerts.filter((alert) => alert.severity === "Critical").length}
              </h2>
            </div>

            <div className="alert-summary-card">
              <h3>Warning Alerts</h3>
              <h2>
                {alerts.filter((alert) => alert.severity === "Warning").length}
              </h2>
            </div>
          </div>

          <section className="alerts-list">
            <h3>Current Simulation Alerts</h3>

            {alerts.length === 0 ? (
              <p>No unmet-demand alerts in the latest simulation.</p>
            ) : (
              alerts.map((alert, index) => (
                <div
                  className={`alert-item ${alert.severity.toLowerCase()}`}
                  key={`${alert.title}-${index}`}
                >
                  <strong>{alert.severity}</strong>
                  <h4>{alert.title}</h4>
                  <p>{alert.message}</p>
                </div>
              ))
            )}
          </section>

          <p className="timestamp">
            Based on simulation: {dashboard.timestamp}
          </p>
        </>
      )}
    </div>
  );
}

export default Alerts;
