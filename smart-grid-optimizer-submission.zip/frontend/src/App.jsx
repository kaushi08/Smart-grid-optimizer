
import { useEffect, useState } from "react";
import "./App.css";

import Optimization from "./Optimization.jsx";
import Charts from "./Charts.jsx";
import ZoneManagement from "./ZoneManagement.jsx";
import DemandPrediction from "./DemandPrediction.jsx";
import GridSimulation from "./GridSimulation.jsx";
import Alerts from "./Alerts.jsx";

function App() {
  const [page, setPage] = useState("dashboard");
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/dashboard")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Unable to fetch dashboard data.");
        }
        return response.json();
      })
      .then((data) => {
        setDashboard(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>AI-Powered Smart Grid Management System</h1>
        <p>Intelligent Load Balancing and Energy Distribution</p>
      </header>

      <nav className="navigation">
        <button onClick={() => setPage("dashboard")}>Dashboard</button>
        <button onClick={() => setPage("optimization")}>
          Intelligent Optimization
        </button>
        <button onClick={() => setPage("zones")}>Zone Management</button>
        <button onClick={() => setPage("predictions")}>
          Demand Prediction
        </button>
        <button onClick={() => setPage("simulation")}>
          Grid Simulation
        </button>
        <button onClick={() => setPage("alerts")}>Alerts</button>
      </nav>

      <main>
        {page === "dashboard" ? (
          <section className="dashboard">
            <h2>Energy Dashboard</h2>

            {loading && <p>Loading dashboard data...</p>}
            {error && <p className="error">{error}</p>}

            {dashboard && (
              <>
                <div className="dashboard-cards">
                  <div className="dashboard-card">
                    <h3>Total Energy Demand</h3>
                    <h2>{dashboard.total_demand_kwh} kWh</h2>
                  </div>

                  <div className="dashboard-card">
                    <h3>Energy Allocated</h3>
                    <h2>{dashboard.total_allocated_kwh} kWh</h2>
                  </div>

                  <div className="dashboard-card">
                    <h3>Unmet Demand</h3>
                    <h2>{dashboard.total_unmet_demand_kwh} kWh</h2>
                  </div>

                  <div className="dashboard-card">
                    <h3>Demand Satisfaction</h3>
                    <h2>{dashboard.demand_satisfaction_percentage}%</h2>
                  </div>
                </div>

                <div className="dashboard-chart">
                  <Charts />
                </div>
              </>
            )}
          </section>
        ) : page === "optimization" ? (
          <Optimization />
        ) : page === "zones" ? (
          <ZoneManagement />
        ) : page === "predictions" ? (
          <DemandPrediction />
        ) : page === "simulation" ? (
          <GridSimulation />
        ) : (
          <Alerts />
        )}
      </main>

      <footer className="app-footer">
        AI-Powered Smart Grid Project | Simulation Environment
      </footer>
    </div>
  );
}

export default App;
