
import { useEffect, useState } from "react";

function ZoneManagement() {
  const [zones, setZones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("http://127.0.0.1:8000/zone-details")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Unable to fetch zone configuration.");
        }
        return response.json();
      })
      .then((data) => {
        setZones(data.zones || []);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  return (
    <div className="zone-management">
      <h2>Zone Management</h2>
      <p>Monitor configured energy zones and their priority levels.</p>

      {loading && <p>Loading zone information...</p>}

      {error && <p className="error">{error}</p>}

      {!loading && !error && (
        <>
          <h3>Total Zones: {zones.length}</h3>

          <div className="zone-grid">
            {zones.map((zone) => (
              <div className="zone-card" key={zone.name}>
                <h3>{zone.name}</h3>
                <p><strong>Priority:</strong> {zone.priority || "Not configured"}</p>
                <p>
                  <strong>Maximum Capacity:</strong>{" "}
                  {zone.max_capacity_kwh ?? "Not configured"} kWh
                </p>
                <p>
                  <strong>Minimum Supply:</strong>{" "}
                  {zone.minimum_supply_fraction != null
                    ? `${(zone.minimum_supply_fraction * 100).toFixed(0)}%`
                    : "Not configured"}
                </p>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default ZoneManagement;
