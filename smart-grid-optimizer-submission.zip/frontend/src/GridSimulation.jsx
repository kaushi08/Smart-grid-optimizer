
import { useEffect, useState } from "react";

function GridSimulation() {
  const [simulation, setSimulation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/dashboard")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Unable to load simulation results.");
        }
        return response.json();
      })
      .then((data) => {
        setSimulation(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  return (
    <div className="simulation-page">
      <h2>Grid Simulation</h2>

      <p>
        Monitor simulated energy distribution across all five smart-grid zones.
      </p>

      {loading && <p>Loading simulation results...</p>}

      {error && <p className="error">{error}</p>}

      {simulation && (
        <>
          <div className="simulation-summary">

            <div className="simulation-card">
              <h3>Total Demand</h3>
              <h2>{simulation.total_demand_kwh} kWh</h2>
            </div>

            <div className="simulation-card">
              <h3>Energy Allocated</h3>
              <h2>{simulation.total_allocated_kwh} kWh</h2>
            </div>

            <div className="simulation-card">
              <h3>Unmet Demand</h3>
              <h2>{simulation.total_unmet_demand_kwh} kWh</h2>
            </div>

            <div className="simulation-card">
              <h3>Demand Satisfaction</h3>
              <h2>{simulation.demand_satisfaction_percentage}%</h2>
            </div>

          </div>

          <section className="simulation-results">
            <h3>Zone-wise Simulation Results</h3>

            <table>
              <thead>
                <tr>
                  <th>Zone</th>
                  <th>Demand (kWh)</th>
                  <th>Allocated (kWh)</th>
                  <th>Unmet (kWh)</th>
                  <th>Satisfaction</th>
                </tr>
              </thead>

              <tbody>
                {simulation.zones.map((zone) => (
                  <tr key={zone.name}>
                    <td>{zone.name}</td>
                    <td>{zone.demand_kwh}</td>
                    <td>{zone.allocated_kwh}</td>
                    <td>{zone.unmet_demand_kwh}</td>
                    <td>{zone.satisfaction_percentage}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>

          <p className="timestamp">
            Latest simulation: {simulation.timestamp}
          </p>
        </>
      )}
    </div>
  );
}

export default GridSimulation;
