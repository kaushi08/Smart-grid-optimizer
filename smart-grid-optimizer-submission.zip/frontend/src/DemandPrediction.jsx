
import { useEffect, useState } from "react";

function DemandPrediction() {
  const [predictions, setPredictions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/predictions")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Unable to fetch demand predictions.");
        }
        return response.json();
      })
      .then((data) => {
        setPredictions(data.predictions || []);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  return (
    <div className="prediction-page">
      <h2>AI Demand Prediction</h2>

      <p>
        XGBoost-based next-hour energy demand predictions
        for the five smart-grid zones.
      </p>

      {loading && <p>Loading predictions...</p>}

      {error && <p className="error">{error}</p>}

      {!loading && !error && (
        <>
          <h3>Total Zones: {predictions.length}</h3>

          <div className="prediction-grid">
            {predictions.map((item) => (
              <div className="prediction-card" key={item.zone}>
                <h3>{item.zone}</h3>

                <h2>
                  {Number(item.predicted_demand_kwh).toFixed(2)} kWh
                </h2>

                <p>Predicted Next-Hour Demand</p>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default DemandPrediction;
