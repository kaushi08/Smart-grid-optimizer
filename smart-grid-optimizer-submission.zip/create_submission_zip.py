
from pathlib import Path
import zipfile

project = Path(r"K:\smart-grid-optimizer")
zip_path = project.parent / "smart-grid-optimizer-submission.zip"

excluded_dirs = {
    ".venv",
    "venv",
    "node_modules",
    ".idea",
    "__pycache__",
    ".git",
    "dist",
    ".pytest_cache"
}

excluded_files = {
    ".DS_Store"
}

file_count = 0

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for current_dir, dirs, files in __import__("os").walk(project):
        dirs[:] = [d for d in dirs if d not in excluded_dirs]

        for filename in files:
            if filename in excluded_files or filename.endswith(".pyc"):
                continue

            file_path = Path(current_dir) / filename
            archive_name = file_path.relative_to(project)

            archive.write(file_path, archive_name)
            file_count += 1

print("SUBMISSION ZIP CREATED SUCCESSFULLY!")
print(f"Files included: {file_count}")
print(f"ZIP location: {zip_path}")
