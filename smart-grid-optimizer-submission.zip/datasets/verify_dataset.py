
import pandas as pd
from pathlib import Path

DATASET_DIR = Path(__file__).resolve().parent

zone_file = DATASET_DIR / "smart_grid_dataset.csv"
system_file = DATASET_DIR / "system_supply_dataset.csv"

print("\n========== DATASET VERIFICATION ==========")

# Check whether files exist
for file in [zone_file, system_file]:
    if not file.exists():
        raise FileNotFoundError(f"Missing file: {file.name}")
    print(f"\nFound: {file.name}")

# Load datasets
zone_data = pd.read_csv(zone_file)
system_data = pd.read_csv(system_file)

# Check row counts
print("\n--- ROW COUNTS ---")
print("Zone records:", len(zone_data))
print("System records:", len(system_data))

assert len(zone_data) == 43800, "Incorrect zone record count"
assert len(system_data) == 8760, "Incorrect system record count"

# Check missing values
print("\n--- MISSING VALUES ---")
print("Zone dataset:", zone_data.isnull().sum().sum())
print("System dataset:", system_data.isnull().sum().sum())

# Check duplicates
print("\n--- DUPLICATE RECORDS ---")
print(
    "Zone duplicates:",
    zone_data.duplicated(["timestamp", "zone"]).sum()
)
print(
    "System duplicates:",
    system_data.duplicated(["timestamp"]).sum()
)

# Check zones
print("\n--- ZONE DETAILS ---")
print(zone_data["zone"].value_counts())

# Check columns
print("\n--- ZONE DATASET COLUMNS ---")
print(zone_data.columns.tolist())

print("\n--- SYSTEM DATASET COLUMNS ---")
print(system_data.columns.tolist())

# Display sample records
print("\n--- SAMPLE ZONE RECORDS ---")
print(zone_data.head())

print("\n--- SAMPLE SYSTEM RECORDS ---")
print(system_data.head())

print("\nDATASET VERIFICATION COMPLETED")
