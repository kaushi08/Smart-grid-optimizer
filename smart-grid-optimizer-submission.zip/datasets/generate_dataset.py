
import numpy as np
import pandas as pd
from pathlib import Path

# --------------------------------------------------
# 1. PROJECT CONFIGURATION
# --------------------------------------------------

OUTPUT_DIR = Path(__file__).resolve().parent

START_DATE = "2025-01-01"
DAYS = 365
RANDOM_SEED = 42

rng = np.random.default_rng(RANDOM_SEED)

ZONES = {
    "Hospital": {
        "base_demand": 120,
        "priority": "Critical",
        "minimum_supply_fraction": 0.90
    },
    "Emergency Centre": {
        "base_demand": 70,
        "priority": "Critical",
        "minimum_supply_fraction": 0.90
    },
    "Residential": {
        "base_demand": 180,
        "priority": "High",
        "minimum_supply_fraction": 0.60
    },
    "Commercial": {
        "base_demand": 140,
        "priority": "Medium",
        "minimum_supply_fraction": 0.40
    },
    "Industrial": {
        "base_demand": 220,
        "priority": "Medium",
        "minimum_supply_fraction": 0.50
    }
}

# --------------------------------------------------
# 2. GENERATE HOURLY TIMESTAMPS
# --------------------------------------------------

timestamps = pd.date_range(
    start=START_DATE,
    periods=DAYS * 24,
    freq="h"
)

hour = timestamps.hour.to_numpy()
day_of_week = timestamps.dayofweek.to_numpy()
day_of_year = timestamps.dayofyear.to_numpy()

is_weekend = (day_of_week >= 5).astype(int)

# --------------------------------------------------
# 3. GENERATE TEMPERATURE
# --------------------------------------------------

daily_temperature = (
    28
    + 5 * np.sin(2 * np.pi * (day_of_year - 80) / 365)
    + 2 * np.sin(2 * np.pi * (hour - 14) / 24)
)

temperature = daily_temperature + rng.normal(
    0, 1.5, len(timestamps)
)

temperature = np.clip(temperature, 15, 42)

# --------------------------------------------------
# 4. GENERATE DEMAND FOR EACH ZONE
# --------------------------------------------------

zone_records = []

for zone_name, config in ZONES.items():

    base = config["base_demand"]

    # Default hourly demand profile
    hourly_factor = np.ones(len(timestamps))

    if zone_name == "Hospital":
        hourly_factor += 0.08 * np.sin(
            2 * np.pi * (hour - 8) / 24
        )

    elif zone_name == "Emergency Centre":
        hourly_factor += 0.05 * np.sin(
            2 * np.pi * (hour - 6) / 24
        )

    elif zone_name == "Residential":
        hourly_factor += 0.20 * np.isin(
            hour, [6, 7, 8, 19, 20, 21, 22]
        )

    elif zone_name == "Commercial":
        hourly_factor += 0.30 * np.isin(
            hour, range(9, 18)
        )

    elif zone_name == "Industrial":
        hourly_factor += 0.25 * np.isin(
            hour, range(8, 19)
        )

    # Reduce commercial and industrial activity on weekends
    if zone_name in ["Commercial", "Industrial"]:
        hourly_factor *= np.where(
            is_weekend == 1, 0.75, 1.0
        )

    # Temperature-sensitive electricity demand
    temperature_factor = (
        1
        + np.maximum(temperature - 30, 0) * 0.015
        + np.maximum(22 - temperature, 0) * 0.008
    )

    # Random variation
    random_factor = rng.normal(
        1.0, 0.04, len(timestamps)
    )

    demand = (
        base
        * hourly_factor
        * temperature_factor
        * random_factor
    )

    demand = np.maximum(demand, 1)

    zone_df = pd.DataFrame({
        "timestamp": timestamps,
        "zone": zone_name,
        "hour": hour,
        "day_of_week": day_of_week,
        "month": timestamps.month,
        "is_weekend": is_weekend,
        "temperature_c": np.round(temperature, 2),
        "demand_kwh": np.round(demand, 2),
        "priority_level": config["priority"],
        "minimum_supply_fraction":
            config["minimum_supply_fraction"]
    })

    zone_records.append(zone_df)

# Combine all five zones
zone_data = pd.concat(
    zone_records,
    ignore_index=True
)

# --------------------------------------------------
# 5. GENERATE HOURLY SYSTEM SUPPLY DATA
# --------------------------------------------------

hourly_demand = (
    zone_data.groupby("timestamp")["demand_kwh"]
    .sum()
    .reset_index(name="total_demand_kwh")
)

system_hour = hourly_demand["timestamp"].dt.hour.to_numpy()
system_day = hourly_demand["timestamp"].dt.dayofyear.to_numpy()

# Solar generation: zero at night, higher during daylight
daylight_factor = np.maximum(
    np.sin(np.pi * (system_hour - 6) / 12), 0
)

seasonal_solar_factor = (
    0.85
    + 0.15 * np.sin(
        2 * np.pi * (system_day - 80) / 365
    )
)

solar_generation = (
    150
    * daylight_factor
    * seasonal_solar_factor
    * rng.normal(1.0, 0.05, len(hourly_demand))
)

solar_generation = np.maximum(solar_generation, 0)

# Simulated wind generation
wind_generation = np.maximum(
    rng.normal(55, 10, len(hourly_demand)),
    10
)

# Conventional supply capacity
conventional_supply = (
    hourly_demand["total_demand_kwh"].to_numpy()
    * rng.uniform(0.78, 0.88, len(hourly_demand))
)

# Total available supply
total_available_supply = (
    conventional_supply
    + solar_generation
    + wind_generation
)

system_data = pd.DataFrame({
    "timestamp": hourly_demand["timestamp"],
    "total_demand_kwh": np.round(
        hourly_demand["total_demand_kwh"], 2
    ),
    "conventional_supply_kwh": np.round(
        conventional_supply, 2
    ),
    "solar_generation_kwh": np.round(
        solar_generation, 2
    ),
    "wind_generation_kwh": np.round(
        wind_generation, 2
    ),
    "total_available_supply_kwh": np.round(
        total_available_supply, 2
    )
})

# --------------------------------------------------
# 6. SAVE DATASETS
# --------------------------------------------------

zone_file = OUTPUT_DIR / "smart_grid_dataset.csv"
system_file = OUTPUT_DIR / "system_supply_dataset.csv"

zone_data.to_csv(zone_file, index=False)
system_data.to_csv(system_file, index=False)

# --------------------------------------------------
# 7. VALIDATE DATASETS
# --------------------------------------------------

print("\n========== SMART GRID DATASET REPORT ==========")

print("\nZone dataset records:", len(zone_data))
print("Expected records:", DAYS * 24 * len(ZONES))

print("\nSystem dataset records:", len(system_data))
print("Expected records:", DAYS * 24)

print("\nRecords per zone:")
print(zone_data.groupby("zone").size())

print("\nMissing values:")
print(zone_data.isnull().sum().sum())

print("\nDuplicate zone-hour records:")
print(zone_data.duplicated(["timestamp", "zone"]).sum())

print("\nDemand statistics:")
print(zone_data["demand_kwh"].describe())

print("\nSystem supply statistics:")
print(system_data["total_available_supply_kwh"].describe())

print("\nSaved files:")
print(zone_file)
print(system_file)

print("\nDATASET GENERATION COMPLETED SUCCESSFULLY")
